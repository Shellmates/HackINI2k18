Help! Someone stole my flag and messed around with it!
If my memory is good, my image's height was 100px before losing it.